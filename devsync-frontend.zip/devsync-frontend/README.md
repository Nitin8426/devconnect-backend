# DevSync – Real-Time Collaboration for Developers 🚀

DevSync is a full-stack, real-time collaboration platform built specifically for developers. It combines powerful features from tools like Slack, Trello, GitHub Issues, and VS Code Live Share — into one unified workspace for communication, code collaboration, and team task management.

Whether you're building projects, contributing to open source, or working in a team, DevSync helps you chat, track progress, manage tasks, and code together — all in real time.

---

## 🌟 Key Features

- 🔐 **JWT Authentication** – Secure login with token-based sessions  
- 🧠 **Live Collaborative Code Editor** – Monaco editor powered by CRDT & WebSocket sync  
- 💬 **Real-Time Chat** – Team-based messaging with instant updates  
- ✅ **Kanban Task Board** – Trello-style task management with drag & drop  
- 🐛 **GitHub-style Issue Tracker** – Open, assign, and resolve issues with tags and comments  
- 🔁 **Snapshot Save & Load** – Store and restore code sessions collaboratively  
- ⚙️ **DevOps Ready** – Containerized with Docker, GitHub Actions CI/CD, and Render deployment

---

## 🛠️ Tech Stack

### Backend
- Java 17 + Spring Boot
- Spring Security + JWT
- WebSocket + STOMP (Real-time features)
- PostgreSQL (Structured data)
- Redis (Session + WebSocket pub/sub)
- Kafka (Optional event-driven processing)
- MongoDB (Chat & issues storage)
- Docker + Docker Compose
- GHCR + GitHub Actions for CI/CD

### Frontend
- React 18 + Vite
- Tailwind CSS (UI styling)
- Zustand + Redux Toolkit (State management)
- React Router v6
- Monaco Editor (VS Code editor embedded)
- Lucide Icons + ShadCN UI
- Axios for API requests
- WebSocket client (for real-time sync)
- React Hook Form + Zod for validations

---

## 🚀 Deployment

- Dockerized backend & frontend setup
- GitHub Actions CI/CD configured
- Deployed to Render (or Railway, EC2 optional)
- PostgreSQL, Redis, and MongoDB services connected
- Uses `.env` for environment configuration

---

## 🤝 Contributing

We're open to collaboration! If you're a backend developer, frontend expert, or just love building dev tools, feel free to fork, open issues, or create pull requests.

---

## 📄 License

MIT License. Use it, improve it, share it.

---

## 🧑‍💻 Built By

Nitin Tripathi – Full Stack Developer | AI + Java + React Enthusiast  
[GitHub](https://github.com/Nitin8426)
